<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start();

$host = "localhost";
$usuario_db = "root";
$contrasena_db = ""; // Cambiar si es necesario
$nombre_db = "panaderia_pos";
$puerto = 3308; 

// Establecer conexión
$conexion = new mysqli($host, $usuario_db, $contrasena_db, $nombre_db, $puerto);

if ($conexion->connect_error) {
    die("Error de conexión: " . $conexion->connect_error);
}

// Obtener datos del formulario
$usuario = trim($_POST['usuario'] ?? '');
$contrasena = trim($_POST['contrasena'] ?? '');

// Validación básica
if (empty($usuario) || empty($contrasena)) {
    header("Location: login.html?error=campos_vacios");
    exit();
}

// Consulta preparada (segura contra inyección SQL)
$sql = "SELECT * FROM Cuenta 
        INNER JOIN Empleado ON Cuenta.id_empleado = Empleado.id_empleado
        INNER JOIN Puesto ON Empleado.id_puesto = Puesto.id_puesto
        WHERE usuario = ? AND contraseña = ?";

$stmt = $conexion->prepare($sql);
if (!$stmt) {
    die("Error en preparación: " . $conexion->error);
}

$stmt->bind_param("ss", $usuario, $contrasena);
$stmt->execute();
$resultado = $stmt->get_result();

if ($resultado->num_rows === 1) {
    $fila = $resultado->fetch_assoc();
    
    // Iniciar sesión
    $_SESSION['usuario'] = $fila['usuario'];
    $_SESSION['nombre'] = $fila['nombre'] . ' ' . $fila['apellido_pat'];
    $_SESSION['privilegio'] = $fila['privilegio'];
    
    // Redirección según privilegio
    switch ($fila['privilegio']) {
        case 1: header("Location: ../administrador/productos.html"); break;
        case 2: header("Location: ../panadero/productos.html"); break;
        case 3: header("Location: ../cajero/productos.html"); break;
        default: header("Location: inicio");
    }
    exit();
} else {
    header("Location: inicio.html?error=credenciales");
    exit();
}
$_SESSION['id_empleado'] = $id_empleado_obtenido_de_la_base;


$stmt->close();
$conexion->close();
?>