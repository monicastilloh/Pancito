<?php
require('fpdf/fpdf.php');
include 'conexion.php';

// Configuración de errores
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('log_errors', 1);
ini_set('error_log', 'php_errors.log');

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    try {
        // Validar datos requeridos
        $requiredFields = [
            'carrito', 'tipo_pago', 'total', 
            'nombre', 'correo', 
            'telefono', 'rfc',
            'id_empleado'
        ];
        
        foreach ($requiredFields as $field) {
            if (empty($_POST[$field])) {
                throw new Exception("Campo requerido faltante: $field");
            }
        }

        // Obtener datos del POST
        $carrito = json_decode($_POST['carrito'], true);
        $tipo_pago = $_POST['tipo_pago'];
        $total = (float)$_POST['total'];
        $efectivo = isset($_POST['efectivo']) ? (float)$_POST['efectivo'] : 0;
        $cambio = isset($_POST['cambio']) ? (float)$_POST['cambio'] : 0;
        $id_empleado = (int)$_POST['id_empleado'];

        // Datos del cliente
        $cliente = [
            'nombre' => $_POST['nombre'],
            'telefono' => $_POST['telefono'],
            'correo' => $_POST['correo'],
            'rfc' => strtoupper($_POST['rfc'])
        ];

        // Validar RFC
        if (!preg_match('/^[A-ZÑ&]{3,4}\d{6}[A-Z0-9]{2}[0-9A]$/', $cliente['rfc'])) {
            throw new Exception("El RFC no tiene un formato válido");
        }

        // Iniciar transacción
        mysqli_begin_transaction($conexion);

        
        if (!$stmtVenta || !mysqli_stmt_bind_param($stmtVenta, 'dii', $total, $id_empleado, $tipo_pago) || !mysqli_stmt_execute($stmtVenta)) {
            throw new Exception("Error al insertar venta: " . ($stmtVenta ? mysqli_stmt_error($stmtVenta) : mysqli_error($conexion)));
        }

        $id_venta = mysqli_insert_id($conexion);

        // 2. Registrar detalles de venta
        $queryDetalle = "INSERT INTO DetalleVenta (id_venta, id_producto, cantidad, precio_unitario, subtotal) VALUES (?, ?, ?, ?, ?)";
        $stmtDetalle = mysqli_prepare($conexion, $queryDetalle);
        
        if (!$stmtDetalle) {
            throw new Exception("Error preparando query de detalle: " . mysqli_error($conexion));
        }

        foreach ($carrito as $item) {
            if (!isset($item['id'], $item['cantidad'], $item['precio'], $item['subtotal'])) {
                throw new Exception("Ítem de carrito incompleto");
            }

            $id_producto = (int)$item['id'];
            $cantidad = (int)$item['cantidad'];
            $precio = (float)$item['precio'];
            $subtotal = (float)$item['subtotal'];

            if (!mysqli_stmt_bind_param($stmtDetalle, 'iiidd', $id_venta, $id_producto, $cantidad, $precio, $subtotal) || 
                !mysqli_stmt_execute($stmtDetalle)) {
                throw new Exception("Error al insertar detalle: " . mysqli_stmt_error($stmtDetalle));
            }
        }

        // 3. Registrar cliente (si no existe)
        $queryCliente = "SELECT id_cliente FROM Cliente WHERE RFC = ?";
        $stmtCliente = mysqli_prepare($conexion, $queryCliente);
        mysqli_stmt_bind_param($stmtCliente, 's', $cliente['rfc']);
        mysqli_stmt_execute($stmtCliente);
        $result = mysqli_stmt_get_result($stmtCliente);
        
        if ($result && mysqli_num_rows($result) === 0) {
            // Insertar nuevo cliente
            $queryInsertCliente = "INSERT INTO Cliente (nombre, apellido_paterno, apellido_materno, fecha_nacimiento, telefono, correo, RFC) 
                                 VALUES (?, ?, ?, ?, ?, ?, ?)";
            $stmtInsertCliente = mysqli_prepare($conexion, $queryInsertCliente);
            mysqli_stmt_bind_param($stmtInsertCliente, 'sssssss', 
                $cliente['nombre'],
                $cliente['telefono'],
                $cliente['correo'],
                $cliente['rfc']
            );
            mysqli_stmt_execute($stmtInsertCliente);
            $id_cliente = mysqli_insert_id($conexion);
        } else {
            $row = mysqli_fetch_assoc($result);
            $id_cliente = $row['id_cliente'];
        }

        // 4. Registrar factura
        $queryFactura = "INSERT INTO Factura (id_venta, id_cliente, fecha_emision, total) VALUES (?, ?, NOW(), ?)";
        $stmtFactura = mysqli_prepare($conexion, $queryFactura);
        mysqli_stmt_bind_param($stmtFactura, 'iid', $id_venta, $id_cliente, $total);
        mysqli_stmt_execute($stmtFactura);
        $id_factura = mysqli_insert_id($conexion);

        // 5. Generar PDF de la factura
        $pdf = new FPDF();
        $pdf->AddPage();
        $pdf->SetFont('Arial', 'B', 12);

        // Encabezado
        $pdf->Cell(0, 10, 'FACTURA FISCAL', 0, 1, 'C');
        $pdf->SetFont('Arial', '', 10);
        $pdf->Cell(0, 10, 'No. Factura: ' . str_pad($id_factura, 8, '0', STR_PAD_LEFT), 0, 1);
        $pdf->Cell(0, 10, 'Fecha: ' . date('d/m/Y H:i:s'), 0, 1);
        $pdf->Ln(10);

        // Datos del cliente
        $pdf->SetFont('Arial', 'B', 10);
        $pdf->Cell(0, 10, 'DATOS DEL CLIENTE', 0, 1);
        $pdf->SetFont('Arial', '', 10);
        $pdf->Cell(0, 10, 'Nombre: ' . $cliente['nombre'] . ' ' . $cliente['apellido_paterno'] . ' ' . $cliente['apellido_materno'], 0, 1);
        $pdf->Cell(0, 10, 'RFC: ' . $cliente['rfc'], 0, 1);
        $pdf->Cell(0, 10, 'Fecha Nacimiento: ' . $cliente['fecha_nacimiento'], 0, 1);
        $pdf->Cell(0, 10, 'Contacto: ' . $cliente['telefono'] . ' / ' . $cliente['correo'], 0, 1);
        $pdf->Ln(10);

        // Detalles de la venta
        $pdf->SetFont('Arial', 'B', 10);
        $pdf->Cell(80, 10, 'Producto', 1, 0, 'C');
        $pdf->Cell(30, 10, 'Cantidad', 1, 0, 'C');
        $pdf->Cell(30, 10, 'Precio', 1, 0, 'C');
        $pdf->Cell(30, 10, 'Subtotal', 1, 1, 'C');
        
        $pdf->SetFont('Arial', '', 10);
        foreach ($carrito as $producto) {
            $pdf->Cell(80, 10, $producto['nombre'], 1, 0);
            $pdf->Cell(30, 10, $producto['cantidad'], 1, 0, 'C');
            $pdf->Cell(30, 10, '$' . number_format($producto['precio'], 2), 1, 0, 'R');
            $pdf->Cell(30, 10, '$' . number_format($producto['subtotal'], 2), 1, 1, 'R');
        }

        // Totales
        // Guardar la posición actual para volver después
        $y_totales = $pdf->GetY();

        // Ir al final de la página antes de agregar totales y método de pago
        $pdf->SetY(-60);

        $pdf->Ln(5);
        $pdf->Cell(140, 10, 'Subtotal:', 0, 0, 'R');
        $pdf->Cell(30, 10, '$' . number_format($total, 2), 0, 1, 'R');
        
        $iva = $total * 0.16;
        $pdf->Cell(140, 10, 'IVA (16%):', 0, 0, 'R');
        $pdf->Cell(30, 10, '$' . number_format($iva, 2), 0, 1, 'R');
        
        $total_con_iva = $total + $iva;
        $pdf->SetFont('Arial', 'B', 10);
        $pdf->Cell(140, 10, 'Total:', 0, 0, 'R');
        $pdf->Cell(30, 10, '$' . number_format($total_con_iva, 2), 0, 1, 'R');
        
        // Información de pago
        $pdf->Ln(10);
        $pdf->Cell(0, 10, 'Metodo de pago: ' . $tipo_pago, 0, 1);
        if ($tipo_pago === 'Efectivo') {
            $pdf->Cell(0, 10, 'Efectivo recibido: $' . number_format($efectivo, 2), 0, 1);
            $pdf->Cell(0, 10, 'Cambio: $' . number_format($cambio, 2), 0, 1);
        }

        // Regresar a la posición original si es necesario
        $pdf->SetY($y_totales);

        // Guardar PDF en servidor
        $pdf_path = 'facturas/Factura_' . $id_factura . '.pdf';
        $pdf->Output('F', $pdf_path);

        // Confirmar transacción
        mysqli_commit($conexion);

        // Devolver respuesta con URL del PDF
        echo json_encode([
            'success' => true,
            'message' => 'Factura generada correctamente',
            'pdf_url' => $pdf_path,
            'id_factura' => $id_factura
        ]);

    } catch (Exception $e) {
        // Revertir transacción en caso de error
        mysqli_rollback($conexion);
        
        error_log("Error al generar factura: " . $e->getMessage());
        echo json_encode([
            'success' => false,
            'message' => 'Error al generar factura: ' . $e->getMessage()
        ]);
    }
} else {
    echo json_encode([
        'success' => false,
        'message' => 'Método no permitido'
    ]);
}
?>