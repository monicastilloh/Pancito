<?php
include 'conexion.php';
if ($conexion->connect_error) {
    die("Error: " . $conexion->connect_error);
}

$id_producto = intval($_GET['id_producto']);

$sql = "
    SELECT i.nombre
    FROM IngredienteProducto ip
    INNER JOIN Ingrediente i ON ip.id_ingrediente = i.id_ingrediente
    WHERE ip.id_producto = $id_producto
";

$resultado = $conexion->query($sql);

$ingredientes = [];
while ($row = $resultado->fetch_assoc()) {
    $ingredientes[] = $row;
}

header('Content-Type: application/json');
echo json_encode($ingredientes);
?>
