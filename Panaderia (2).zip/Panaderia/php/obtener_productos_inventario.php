<?php
include 'conexion.php';

$sql = "SELECT id_producto, nombre, descripcion, imagen, stock FROM Producto";
$resultado = $conexion->query($sql);

$productos = [];

while ($row = $resultado->fetch_assoc()) {
    $productos[] = $row;
}

echo json_encode($productos);

$conexion->close();
?>
