<?php
include 'conexion.php';

if (!isset($_GET['id_producto'])) {
    http_response_code(400);
    echo json_encode(['error' => 'ID de producto no proporcionado']);
    exit;
}

$id = intval($_GET['id_producto']);

$query = "SELECT * FROM Producto WHERE id_producto = $id and stock > 0";
$result = mysqli_query($conexion, $query);

if (!$result || mysqli_num_rows($result) === 0) {
    http_response_code(404);
    echo json_encode(['error' => 'Producto no encontrado']);
    exit;
}

$producto = mysqli_fetch_assoc($result);

// Obtener ingredientes
$ingredientes = [];
$queryIng = "SELECT i.nombre, ip.cantidad_utilizada_mg as cantidad
             FROM Ingrediente i
             JOIN IngredienteProducto ip ON i.id_ingrediente = ip.id_ingrediente
             WHERE ip.id_producto = $id";
$resultIng = mysqli_query($conexion, $queryIng);

while ($row = mysqli_fetch_assoc($resultIng)) {
    $ingredientes[] = $row;
}

$producto['ingredientes'] = $ingredientes;

header('Content-Type: application/json');
echo json_encode($producto);
?>
