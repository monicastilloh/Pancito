<?php
$host = 'localhost';
$usuario = 'root';
$contrasena = '';
$base_datos = 'panaderia_pos';
$puerto = 3308;

$conexion = new mysqli($host, $usuario, $contrasena, $base_datos, $puerto);

if ($conexion->connect_error) {
    die("Conexión fallida: " . $conexion->connect_error);
}
?>