<?php
include 'conexion.php';

$id = $_POST['id_empleado'];

$sql = "DELETE FROM Empleado WHERE id_empleado = ?";
$stmt = $conexion->prepare($sql);
$stmt->bind_param("i", $id);

if ($stmt->execute()) {
    echo "Empleado eliminado correctamente.";
} else {
    echo "Error al eliminar empleado.";
}

$stmt->close();
$conexion->close();
?>
