// php/obtener_municipios.php
<?php
include 'conexion.php';
$id_estado = $_GET['id_estado'];
$resultado = $conexion->query("SELECT * FROM Municipio WHERE id_estado = $id_estado");
while ($fila = $resultado->fetch_assoc()) {
    echo "<option value='{$fila['id_municipio']}'>{$fila['nombre']}</option>";
}
?>