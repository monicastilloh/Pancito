<?php
include 'conexion.php';

$id = $_POST['id_empleado'];
$nombre = $_POST['nombre'];
$apellido_pat = $_POST['apellido_pat'];
$apellido_mat = $_POST['apellido_mat'];
$telefono = $_POST['telefono'];
$RFC = $_POST['RFC'];
$correo = $_POST['correo'];

$sql = "UPDATE Empleado SET nombre=?, apellido_pat=?, apellido_mat=?, telefono=?, RFC=?, correo=? WHERE id_empleado=?";
$stmt = $conexion->prepare($sql);
$stmt->bind_param("ssssssi", $nombre, $apellido_pat, $apellido_mat, $telefono, $RFC, $correo, $id);

if ($stmt->execute()) {
    echo "Empleado actualizado correctamente.";
} else {
    echo "Error al actualizar empleado.";
}

$stmt->close();
$conexion->close();
?>
