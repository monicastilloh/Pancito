<?php
require_once("conexion.php");

$id_producto = $_POST['id_producto'] ?? null;
$cantidad = $_POST['cantidad'] ?? null;

if ($id_producto && $cantidad) {
    $stmt = $conexion->prepare("UPDATE Producto SET stock = stock + ? WHERE id_producto = ?");
    $stmt->bind_param("ii", $cantidad, $id_producto);

    if ($stmt->execute()) {
        $response = ['success' => true, 'message' => 'Stock actualizado correctamente.'];
    } else {
        $response = ['success' => false, 'message' => 'Error al actualizar el stock.'];
    }
} else {
    $response = ['success' => false, 'message' => 'Datos incompletos.'];
}

header('Content-Type: application/json');
echo json_encode($response);
?>
