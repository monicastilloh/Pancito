<?php
require('fpdf/fpdf.php'); // Ajusta la ruta según tu estructura

$pdf = new FPDF();
$pdf->AddPage();
$pdf->SetFont('Arial', 'B', 16);
$pdf->Cell(40, 10, '¡FPDF funciona!');
$pdf->Output();
?>

