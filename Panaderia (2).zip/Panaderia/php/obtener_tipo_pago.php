<?php
include 'conexion.php'; // Asegúrate de que la ruta sea correcta

header('Content-Type: application/json');

$sql = "SELECT id_tipo_pago, nombre FROM TipoPago";
$resultado = $conexion->query($sql);

$tipos = [];
while ($row = $resultado->fetch_assoc()) {
    $tipos[] = $row;
}

echo json_encode($tipos);
$conexion->close();
?>
