
<?php
include 'conexion.php';

$cliente = $_POST['cliente'];
$fecha = $_POST['fecha'];
$estado = $_POST['estado'];
$municipio = $_POST['municipio'];
$colonia = $_POST['colonia'];
$calle = $_POST['calle'];
$numero = $_POST['numero'];
$productos = $_POST['productos'];
$cantidades = $_POST['cantidades'];

// Insertar dirección
$conexion->query("INSERT INTO Direccion (calle, numero, id_colonia) VALUES ('$calle', $numero, $colonia)");
$id_direccion = $conexion->insert_id;

// Insertar evento
$total = 0;
foreach ($productos as $id_producto) {
    $precio = $conexion->query("SELECT precio FROM Producto WHERE id_producto = $id_producto")->fetch_assoc()['precio'];
    $subtotal = $precio * $cantidades[$id_producto];
    $total += $subtotal;
}
$conexion->query("INSERT INTO Evento (fecha, id_direccion, total) VALUES ('$fecha', $id_direccion, $total)");
$id_evento = $conexion->insert_id;

// Insertar cliente
$conexion->query("INSERT INTO Cliente (nombre) VALUES ('$cliente')");
$id_cliente = $conexion->insert_id;

// Insertar detalle
foreach ($productos as $id_producto) {
    $precio = $conexion->query("SELECT precio FROM Producto WHERE id_producto = $id_producto")->fetch_assoc()['precio'];
    $subtotal = $precio * $cantidades[$id_producto];
    $conexion->query("INSERT INTO DetalleEvento (id_cliente, id_evento, id_producto, cantidad, subtotal) VALUES ($id_cliente, $id_evento, $id_producto, {$cantidades[$id_producto]}, $subtotal)");
}

echo "Evento registrado correctamente.";
?>