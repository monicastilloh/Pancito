<?php
// config_sesion.php
session_set_cookie_params([
    'lifetime' => 86400, // 1 día
    'path' => '/',
    'domain' => $_SERVER['HTTP_HOST'],
    'secure' => isset($_SERVER['HTTPS']), // Solo HTTPS si está disponible
    'httponly' => true,
    'samesite' => 'Strict'
]);

ini_set('session.cookie_secure', 1);
ini_set('session.cookie_httponly', 1);
ini_set('session.use_strict_mode', 1);
ini_set('session.gc_maxlifetime', 86400);