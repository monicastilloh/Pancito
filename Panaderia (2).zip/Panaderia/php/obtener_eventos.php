<?php
include 'conexion.php';

$sql = "SELECT 
            e.id_evento,
            e.fecha,
            e.total,
            e.anticipo,
            e.debe,
            cl.nombre AS nombre_cliente,
            cl.telefono,
            cl.correo as email,
            d.calle,
            d.numero,
            c.nombre AS colonia,
            m.nombre AS municipio,
            es.nombre AS estado
        FROM Evento e
        LEFT JOIN cliente cl ON e.id_cliente = cl.id_cliente
        LEFT JOIN Direccion d ON e.id_direccion = d.id_direccion
        LEFT JOIN Colonia c ON d.id_colonia = c.id_colonia
        LEFT JOIN Municipio m ON c.id_municipio = m.id_municipio
        LEFT JOIN Estado es ON m.id_estado = es.id_estado
        ORDER BY e.fecha ASC";

$resultado = $conexion->query($sql);
$eventos = [];

while ($row = $resultado->fetch_assoc()) {
    $id_evento = $row['id_evento'];

    // Dirección formateada
    $direccion = $row['calle'] . ' ' . $row['numero'] . ', ' . $row['colonia'] . ', ' . $row['municipio'] . ', ' . $row['estado'];

    // Obtener los productos relacionados a este evento
    $sql_detalle = "SELECT 
                        p.nombre, 
                        de.cantidad, 
                        de.subtotal
                    FROM DetalleEvento de
                    JOIN Producto p ON de.id_producto = p.id_producto
                    WHERE de.id_evento = $id_evento";

    $resultado_detalle = $conexion->query($sql_detalle);
    $detalles = [];

    while ($det = $resultado_detalle->fetch_assoc()) {
        $detalles[] = [
            'nombre' => $det['nombre'],
            'cantidad' => $det['cantidad'],
            'subtotal' => $det['subtotal']
        ];
    }

    $eventos[] = [
        'id_evento' => $id_evento,
        'fecha' => $row['fecha'],
        'total' => $row['total'],
        'pagado' => $row['anticipo'],
        'adeudo' => $row['debe'],
        'nombre_cliente' => $row['nombre_cliente'],
        'telefono' => $row['telefono'],
        'email' => $row['email'],
        'direccion' => $direccion,
        'detalles' => $detalles
    ];
}

echo json_encode($eventos, JSON_UNESCAPED_UNICODE);
?>
