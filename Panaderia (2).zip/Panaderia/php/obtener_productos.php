<?php
include 'conexion.php';

if ($conexion->connect_error) {
    die("Error: " . $conexion->connect_error);
}

$sql = "SELECT id_producto, nombre, descripcion, precio, imagen FROM Producto ORDER BY nombre ASC";
$resultado = $conexion->query($sql);

$productos = [];
while ($row = $resultado->fetch_assoc()) {
    $productos[] = $row;
}

header('Content-Type: application/json');
echo json_encode($productos);
?>
