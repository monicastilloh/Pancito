<?php

header('Content-Type: application/json');
include 'conexion.php';

if ($conexion->connect_error) {
    die(json_encode(["error" => "Error de conexión: " . $conexion->connect_error]));
}

if (isset($_GET['id_producto'])) {
    $idProducto = intval($_GET['id_producto']);

    // Obtener receta
    $sqlReceta = "SELECT nombre, descripcion FROM Receta WHERE id_producto = ?";
    $stmtReceta = $conexion->prepare($sqlReceta);
    $stmtReceta->bind_param("i", $idProducto);
    $stmtReceta->execute();
    $resultadoReceta = $stmtReceta->get_result();

    if ($resultadoReceta->num_rows > 0) {
        $receta = $resultadoReceta->fetch_assoc();

        // Obtener ingredientes
        $sqlIngredientes = "
            SELECT i.nombre AS nombre_ingrediente, ip.cantidad_utilizada_mg, i.unidad_medida
            FROM IngredienteProducto ip
            INNER JOIN Ingrediente i ON ip.id_ingrediente = i.id_ingrediente
            WHERE ip.id_producto = ?
        ";
        $stmtIng = $conexion->prepare($sqlIngredientes);
        $stmtIng->bind_param("i", $idProducto);
        $stmtIng->execute();
        $resultadoIng = $stmtIng->get_result();

        $ingredientes = [];
        while ($fila = $resultadoIng->fetch_assoc()) {
            $ingredientes[] = $fila;
        }

        echo json_encode([
            "receta" => $receta,
            "ingredientes" => $ingredientes
        ]);

        $stmtIng->close();
    } else {
        echo json_encode(["error" => "No se encontró la receta para el producto especificado."]);
    }

    $stmtReceta->close();
} else {
    echo json_encode(["error" => "No se proporcionó el id_producto."]);
}
?>
