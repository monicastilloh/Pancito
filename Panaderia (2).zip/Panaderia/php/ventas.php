<?php
// php/ventas.php
error_reporting(E_ALL);
ini_set('display_errors', 1);

$conexion = new mysqli("localhost", "root", "", "panaderia_pos", 3306);
if ($conexion->connect_error) {
    die("Error de conexión: " . $conexion->connect_error);
}

$sql = "SELECT id_producto, nombre, descripcion, precio, imagen FROM Producto";
$resultado = $conexion->query($sql);

$productos = [];
while ($fila = $resultado->fetch_assoc()) {
    $fila['imagen'] = base64_encode($fila['imagen']);
    $productos[] = $fila;
}

echo json_encode($productos);

$conexion->close();
?>
