<?php
include 'conexion.php';

$id_evento = $_GET['id_evento'];

$sql = "SELECT p.nombre AS producto, de.cantidad, de.subtotal,
               d.calle, d.numero, col.nombre AS colonia, mun.nombre AS ciudad, est.nombre AS estado,
               c.nombre AS cliente, e.total
        FROM DetalleEvento de
        JOIN Producto p ON p.id_producto = de.id_producto
        JOIN Evento e ON e.id_evento = de.id_evento
        JOIN Direccion d ON d.id_direccion = e.id_direccion
        JOIN Colonia col ON col.id_colonia = d.id_colonia
        JOIN Municipio mun ON mun.id_municipio = col.id_municipio
        JOIN Estado est ON est.id_estado = mun.id_estado
        JOIN Cliente c ON c.id_cliente = de.id_cliente
        WHERE e.id_evento = ?";

$stmt = $conexion->prepare($sql);
$stmt->bind_param("i", $id_evento);
$stmt->execute();
$result = $stmt->get_result();

$detalles = [];
while ($row = $result->fetch_assoc()) {
    $detalles[] = $row;
}

echo json_encode($detalles);
?>
