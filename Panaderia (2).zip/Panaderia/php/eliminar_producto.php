<?php

header('Content-Type: application/json');
include 'conexion.php';

if ($conexion->connect_error) {
    die(json_encode(["success" => false, "error" => "Error de conexión: " . $conexion->connect_error]));
}

parse_str(file_get_contents("php://input"), $_DELETE);

if (isset($_DELETE['id_producto'])) {
    $id = intval($_DELETE['id_producto']);
    $sql = "DELETE FROM producto WHERE id_producto = ?";
    $stmt = $conexion->prepare($sql);
    $stmt->bind_param("i", $id);

    if ($stmt->execute()) {
        echo json_encode(["success" => true]);
    } else {
        echo json_encode(["success" => false, "error" => $conexion->error]);
    }

    $stmt->close();
} else {
    echo json_encode(["success" => false, "error" => "ID no recibido"]);
}

$conexion->close();
?>
