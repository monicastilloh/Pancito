<?php
include 'conexion.php';

$sql = "SELECT e.id_empleado, e.nombre, e.apellido_pat, e.apellido_mat,e.sueldo, e.telefono, e.RFC, e.correo,
               d.calle, d.numero, 
               p.nombre AS puesto,
               c.nombre AS colonia,
            m.nombre AS municipio,
            es.nombre AS estado
        FROM Empleado e
        LEFT JOIN Direccion d ON e.id_direccion = d.id_direccion
        LEFT JOIN Colonia c ON d.id_colonia = c.id_colonia
        LEFT JOIN Municipio m ON c.id_municipio = m.id_municipio
        LEFT JOIN Estado es ON m.id_estado = es.id_estado
        LEFT JOIN Puesto p ON e.id_puesto = p.id_puesto";

$result = $conexion->query($sql);
$empleados = [];

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $empleados[] = $row;
    }
}

echo json_encode($empleados);
$conexion->close();
?>
