<?php
require('fpdf/fpdf.php');

$carrito = isset($_POST['carrito']) ? json_decode($_POST['carrito'], true) : [];
$tipo_pago = $_POST['tipo_pago'] ?? 'Desconocido';
$efectivo = isset($_POST['efectivo']) ? floatval($_POST['efectivo']) : 0;
$cambio = isset($_POST['cambio']) ? floatval($_POST['cambio']) : 0;

if (empty($carrito)) {
  http_response_code(400);
  echo "Carrito vacío.";
  exit;
}

class PDF extends FPDF {
  function Header() {
    $this->Image('../img/2.png', 10, 6, 20);
    $this->SetFont('Arial', 'B', 16);
    $this->Cell(0, 10, '', 0, 1, 'C');
    $this->SetFont('Arial', 'B', 12);
    $this->Cell(0, 10, 'Panaderia Pancito', 0, 1, 'C');
    $this->SetFont('Arial', '', 10);
    $this->Cell(0, 10, date('d/m/Y H:i'), 0, 1, 'C');
    $this->Ln(5);
  }

  function Footer() {
    $this->SetY(-15);
    $this->SetFont('Arial', 'I', 8);
    $this->Cell(0, 10, 'Gracias por su compra', 0, 0, 'C');
  }
}

$pdf = new PDF('P', 'mm', array(80, 200));
$pdf->AddPage();
$pdf->SetFont('Arial', '', 10);

$subtotal = 0;
$iva = 0;
$total = 0;

foreach ($carrito as $item) {
  $pdf->Cell(0, 6, "{$item['nombre']} x{$item['cantidad']} - $" . number_format($item['precio'], 2), 0, 1);
  $subtotal += $item['subtotal'];
  $iva += $item['iva'];
  $total += $item['total'];
}

$pdf->Ln(2);
$pdf->Cell(0, 6, '------------------------------', 0, 1);
$pdf->Cell(0, 6, 'Subtotal: $' . number_format($subtotal, 2), 0, 1);
$pdf->Cell(0, 6, 'IVA: $' . number_format($iva, 2), 0, 1);
$pdf->Cell(0, 6, 'Total: $' . number_format($total, 2), 0, 1);
$pdf->Ln(1);
$pdf->Cell(0, 6, 'Pago: ' . $tipo_pago, 0, 1);

if (strtolower($tipo_pago) === 'efectivo') {
  $pdf->Cell(0, 6, 'Efectivo: $' . number_format($efectivo, 2), 0, 1);
  $pdf->Cell(0, 6, 'Cambio: $' . number_format($cambio, 2), 0, 1);
}

$pdf->Output('I', 'ticket.pdf');
?>
