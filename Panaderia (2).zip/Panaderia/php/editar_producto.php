<?php
include 'conexion.php';

header('Content-Type: application/json'); // Asegurar que la respuesta sea JSON

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id_producto = $_GET['id_producto'] ?? null;

    // Obtener datos del formulario
    $nombre = $_POST['nombre'] ?? '';
    $precio = $_POST['precio'] ?? 0;
    $descripcion = $_POST['descripcion'] ?? '';
    $stock_min = $_POST['stock_min'] ?? 0;
    $stock_max = $_POST['stock_max'] ?? 0;
    $stock = $_POST['stock'] ?? 0;
    $id_tipo = $_POST['id_tipo'] ?? 0;
    $receta = $_POST['receta'] ?? '';
    $ingredientes = $_POST['ingredientes'] ?? [];
    $cantidades = $_POST['cantidades'] ?? [];
    $imagen_actual = $_POST['imagen'] ?? $nombre . (str_ends_with($nombre, '.jpg') || str_ends_with($nombre, '.jpeg') ? '' : '.jpg');

    // Validación de campos obligatorios
    if (empty($nombre) || empty($precio) || empty($descripcion) || empty($stock_min) || 
        empty($stock_max) || empty($id_tipo) || empty($receta)) {
        echo json_encode(["success" => false, "message" => "Por favor, complete todos los campos obligatorios."]);
        exit;
    }

    try {
        // Iniciar transacción
        $conexion->begin_transaction();

        // Actualizar producto
        $sql = "UPDATE Producto SET nombre = ?, precio = ?, descripcion = ?, stock_min = ?, 
                stock_max = ?, stock = ?, imagen = ?, id_tipo = ? WHERE id_producto = ?";
        $stmt = $conexion->prepare($sql);
        
        if (!$stmt) {
            throw new Exception("Error al preparar la consulta: " . $conexion->error);
        }
        
        $stmt->bind_param("sdsiiisii", $nombre, $precio, $descripcion, $stock_min, 
                         $stock_max, $stock, $imagen_actual, $id_tipo, $id_producto);
        
        if (!$stmt->execute()) {
            throw new Exception("Error al actualizar el producto: " . $stmt->error);
        }

        // Borrar ingredientes actuales del producto
        $delete = $conexion->prepare("DELETE FROM IngredienteProducto WHERE id_producto = ?");
        $delete->bind_param("i", $id_producto);
        if (!$delete->execute()) {
            throw new Exception("Error al eliminar ingredientes anteriores: " . $delete->error);
        }

        // Insertar ingredientes actualizados
        for ($i = 0; $i < count($ingredientes); $i++) {
            $nombreIngrediente = $ingredientes[$i];
            $cantidad = $cantidades[$i];

            // Verificar si el ingrediente ya existe
            $queryIng = $conexion->prepare("SELECT id_ingrediente FROM Ingrediente WHERE nombre = ?");
            $queryIng->bind_param("s", $nombreIngrediente);
            if (!$queryIng->execute()) {
                throw new Exception("Error al buscar ingrediente: " . $queryIng->error);
            }
            
            $resultIng = $queryIng->get_result();

            if ($rowIng = $resultIng->fetch_assoc()) {
                $id_ingrediente = $rowIng['id_ingrediente'];
            } else {
                // Insertar ingrediente nuevo
                $insertIng = $conexion->prepare("INSERT INTO Ingrediente (nombre) VALUES (?)");
                $insertIng->bind_param("s", $nombreIngrediente);
                if (!$insertIng->execute()) {
                    throw new Exception("Error al insertar ingrediente: " . $insertIng->error);
                }
                $id_ingrediente = $insertIng->insert_id;
                $insertIng->close();
            }
            $queryIng->close();

            // Insertar en IngredienteProducto
            $insertRelacion = $conexion->prepare("INSERT INTO IngredienteProducto (id_producto, id_ingrediente, cantidad_utilizada_mg) VALUES (?, ?, ?)");
            $insertRelacion->bind_param("iii", $id_producto, $id_ingrediente, $cantidad);
            if (!$insertRelacion->execute()) {
                throw new Exception("Error al relacionar ingrediente: " . $insertRelacion->error);
            }
            $insertRelacion->close();
        }

        // Confirmar transacción
        $conexion->commit();
        
        echo json_encode(["success" => true, "message" => "Producto actualizado correctamente"]);
        
    } catch (Exception $e) {
        // Revertir transacción en caso de error
        $conexion->rollback();
        echo json_encode(["success" => false, "message" => $e->getMessage()]);
    }

    // Cerrar conexiones
    if (isset($stmt)) $stmt->close();
    if (isset($delete)) $delete->close();
    
} else {
    echo json_encode(["success" => false, "message" => "Método no permitido."]);
}

$conexion->close();
?>              