<?php
include 'conexion.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre = $_POST['nombre'];
    $precio = $_POST['precio'];
    $receta = $_POST['receta'];
    $ingredientes = $_POST['ingredientes']; // Esto viene como un array JSON
    $imagenNombre = $_FILES['imagen']['name'];
    $imagenTmp = $_FILES['imagen']['tmp_name'];
    $rutaImagen = 'img/' . $imagenNombre;

    // Subir imagen
    move_uploaded_file($imagenTmp, '../' . $rutaImagen);

    // Insertar producto
    $stmt = $conn->prepare("INSERT INTO Producto (nombre, precio, receta, imagen) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("sdss", $nombre, $precio, $receta, $rutaImagen);
    $stmt->execute();
    $id_producto = $conn->insert_id;

    // Insertar ingredientes y relacionarlos
    $ingredientes_array = json_decode($ingredientes, true);

    foreach ($ingredientes_array as $ing) {
        $nombre_ing = $ing['nombre'];
        $unidad = $ing['unidad'];
        $cantidad_utilizada_mg = $ing['cantidad'];

        // Verificar si el ingrediente ya existe
        $stmt = $conn->prepare("SELECT id_ingrediente FROM Ingrediente WHERE nombre = ? AND unidad = ?");
        $stmt->bind_param("ss", $nombre_ing, $unidad);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            // Ya existe, obtener id
            $row = $result->fetch_assoc();
            $id_ingrediente = $row['id_ingrediente'];
        } else {
            // No existe, insertar nuevo
            $stmt = $conn->prepare("INSERT INTO Ingrediente (nombre, unidad) VALUES (?, ?)");
            $stmt->bind_param("ss", $nombre_ing, $unidad);
            $stmt->execute();
            $id_ingrediente = $stmt->insert_id;
        }

        // Insertar en IngredienteProducto
        $stmt = $conn->prepare("INSERT INTO IngredienteProducto (id_producto, id_ingrediente, cantidad_utilizada_mg) VALUES (?, ?, ?)");
        $stmt->bind_param("iid", $id_producto, $id_ingrediente, $cantidad_utilizada_mg);
        $stmt->execute();
    }

    echo json_encode(["success" => true, "message" => "Producto agregado correctamente"]);
} else {
    echo json_encode(["success" => false, "message" => "Método inválido"]);
}
?>
