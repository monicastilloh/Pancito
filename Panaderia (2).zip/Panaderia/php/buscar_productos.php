<?php
require_once("conexion.php");

$busqueda = $_GET['q'] ?? '';

$stmt = $conexion->prepare("SELECT * FROM Producto WHERE nombre LIKE CONCAT( ?)");
$stmt->bind_param("s", $busqueda);
$stmt->execute();
$resultado = $stmt->get_result();

$productos = [];

while ($row = $resultado->fetch_assoc()) {
    $productos[] = $row;
}

header('Content-Type: application/json');
echo json_encode($productos);
?>
