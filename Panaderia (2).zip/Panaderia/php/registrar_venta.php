<?php
include 'conexion.php';
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('log_errors', 1);
ini_set('error_log', 'php_errors.log');
error_log("Datos recibidos: " . print_r($_POST, true));


$id_empleado = $_POST['id_empleado'] ?? $_SESSION['id_empleado'] ?? null;
$carrito = json_decode($_POST['carrito'], true);
$tipo_pago = $_POST['tipo_pago'] ?? null;
$total = $_POST['total'] ?? null;

if (!$id_empleado || !$carrito || !$tipo_pago || !$total) {
    $error = "Datos faltantes: ";
    $error .= !$id_empleado ? "id_empleado " : "";
    $error .= !$carrito ? "carrito " : "";
    $error .= !$tipo_pago ? "tipo_pago " : "";
    $error .= !$total ? "total " : "";
    error_log($error);
    echo json_encode(["success" => false, "message" => $error]);
    exit;
}

mysqli_begin_transaction($conexion);

try {
    // Insertar la venta principal
    $queryVenta = "INSERT INTO Venta (total, id_empleado, id_tipo_pago) VALUES (?, ?, ?)";
    $stmtVenta = mysqli_prepare($conexion, $queryVenta);
    
    if (!$stmtVenta) {
        throw new Exception("Error preparando query Venta: " . mysqli_error($conexion));
    }
    
    mysqli_stmt_bind_param($stmtVenta, 'dii', $total, $id_empleado, $tipo_pago);
    
    if (!mysqli_stmt_execute($stmtVenta)) {
        throw new Exception("Error al insertar venta: " . mysqli_stmt_error($stmtVenta));
    }

    $id_venta = mysqli_insert_id($conexion);
    error_log("Venta insertada con ID: $id_venta");

    // Preparar la consulta para el detalle de venta
    $queryDetalle = "INSERT INTO DetalleVenta (id_venta, id_producto, cantidad, precio_unitario, subtotal) VALUES (?, ?, ?, ?, ?)";
    $stmtDetalle = mysqli_prepare($conexion, $queryDetalle);

    if (!$stmtDetalle) {
        throw new Exception("Error preparando query DetalleVenta: " . mysqli_error($conexion));
    }

    // Preparar la consulta para actualizar el stock
    $queryUpdateStock = "UPDATE Producto SET stock = stock - ? WHERE id_producto = ?";
    $stmtUpdateStock = mysqli_prepare($conexion, $queryUpdateStock);
    
    if (!$stmtUpdateStock) {
        throw new Exception("Error preparando query UpdateStock: " . mysqli_error($conexion));
    }

    // Procesar cada item del carrito
    foreach ($carrito as $item) {
        if (!isset($item['id'], $item['cantidad'], $item['precio'], $item['subtotal'])) {
            error_log("Item incompleto: " . print_r($item, true));
            throw new Exception("Elemento del carrito incompleto.");
        }

        $id_producto = $item['id'];
        $cantidad = $item['cantidad'];
        $precio = $item['precio'];
        $subtotal = $item['subtotal'];

        error_log("Insertando detalle: Venta=$id_venta, Producto=$id_producto, Cant=$cantidad, Precio=$precio, Subtotal=$subtotal");

        // Insertar detalle de venta
        mysqli_stmt_reset($stmtDetalle);
        mysqli_stmt_bind_param($stmtDetalle, 'iiidd', $id_venta, $id_producto, $cantidad, $precio, $subtotal);
        
        if (!mysqli_stmt_execute($stmtDetalle)) {
            throw new Exception("Error al insertar en DetalleVenta: " . mysqli_stmt_error($stmtDetalle));
        }

        // Actualizar stock del producto
        mysqli_stmt_reset($stmtUpdateStock);
        mysqli_stmt_bind_param($stmtUpdateStock, 'ii', $cantidad, $id_producto);
        
        if (!mysqli_stmt_execute($stmtUpdateStock)) {
            throw new Exception("Error al actualizar stock: " . mysqli_stmt_error($stmtUpdateStock));
        }

        error_log("Detalle insertado y stock actualizado correctamente");
    }

    mysqli_commit($conexion);
    error_log("Venta $id_venta registrada exitosamente");
    echo json_encode(["success" => true, "message" => "Venta registrada con éxito.", "id_venta" => $id_venta]);
} catch (Exception $e) {
    mysqli_rollback($conexion);
    error_log("Error en transacción: " . $e->getMessage());
    echo json_encode(["success" => false, "message" => "Error al registrar la venta: " . $e->getMessage()]);
}
?>