<?php
include 'conexion.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Datos del formulario
    $nombre = $_POST['nombre'];
    $apellido_pat = $_POST['apellido_pat'];
    $apellido_mat = $_POST['apellido_mat'];
    $telefono = $_POST['telefono'];
    $RFC = $_POST['RFC'];
    $correo = $_POST['correo'];
    $calle = $_POST['calle'];
    $numero = $_POST['numero'];
    $id_colonia = 2; // Cambiado a null para evitar error si no se envía
    $id_puesto = isset($_POST['id_puesto']) ? intval($_POST['id_puesto']) : null;

    // Validar datos requeridos
    if (!$nombre || !$apellido_pat || !$telefono || !$RFC || !$correo || !$calle || !$numero || !$id_colonia ) {
        echo json_encode(['status' => 'error', 'message' => 'Faltan campos obligatorios.']);
        exit;
    }

    // Insertar en tabla Direccion
    $stmt = $conexion->prepare("INSERT INTO Direccion (calle, numero, id_colonia) VALUES (?, ?, ?)");
    $stmt->bind_param("sii", $calle, $numero, $id_colonia);
    if (!$stmt->execute()) {
        echo json_encode(['status' => 'error', 'message' => 'Error al guardar la dirección.']);
        exit;
    }

    $id_direccion = $stmt->insert_id;

    // Insertar en tabla Empleado
    $stmt = $conexion->prepare("INSERT INTO Empleado (nombre, apellido_pat, apellido_mat, telefono, RFC, correo, id_direccion, id_puesto) 
                            VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssssii", $nombre, $apellido_pat, $apellido_mat, $telefono, $RFC, $correo, $id_direccion, $id_puesto);
    
    if ($stmt->execute()) {
        echo json_encode(['status' => 'success', 'message' => 'Empleado registrado exitosamente.']);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Error al guardar el empleado.']);
    }
}
?>
