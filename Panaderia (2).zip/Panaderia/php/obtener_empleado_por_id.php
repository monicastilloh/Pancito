<?php
include 'conexion.php';

$id = $_GET['id_empleado'];
$sql = "SELECT * FROM Empleado WHERE id_empleado = ?";
$stmt = $conexion->prepare($sql);
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();

echo json_encode($result->fetch_assoc());

$stmt->close();
$conexion->close();
?>
