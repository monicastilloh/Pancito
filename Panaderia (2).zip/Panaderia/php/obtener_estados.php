// php/obtener_estados.php
<?php
include 'conexion.php';
$resultado = $conexion->query("SELECT * FROM Estado");
while ($fila = $resultado->fetch_assoc()) {
    echo "<option value='{$fila['id_estado']}'>{$fila['nombre']}</option>";
}
?>