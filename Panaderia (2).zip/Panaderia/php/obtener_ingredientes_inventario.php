<?php
include 'conexion.php';

$sql = "SELECT 
            I.id_ingrediente,
            I.nombre,
            I.unidad_medida,
            I.minimo,
            I.maximo,
            I.stock,
            P.nombre AS proveedor,
            P.telefono,
            P.correo,
            D.calle,
            D.numero,
            l.id_lote as lote,
            l.fecha_caducidad as caducidad,
            l.fecha_entrada as ingreso
        FROM Ingrediente I
        LEFT JOIN Proveedor P ON I.id_proveedor = P.id_proveedor
        LEFT JOIN  lote l ON I.id_ingrediente = l.id_ingrediente
        LEFT JOIN Direccion D ON P.id_direccion = D.id_direccion";

$resultado = $conexion->query($sql);

$ingredientes = [];

while ($fila = $resultado->fetch_assoc()) {
    $fila['direccion'] = $fila['calle'] . ' #' . $fila['numero'] ;
    $ingredientes[] = $fila;
}

echo json_encode($ingredientes);
?>
