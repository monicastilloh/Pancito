<?php
include 'conexion.php';

$cp = $_GET['cp'] ?? '';

$sql = "SELECT 
            c.id_colonia, c.nombre AS nombre_colonia,
            e.nombre AS estado
        FROM Colonia c
        JOIN Municipio m ON c.id_municipio = m.id_municipio
        JOIN Estado e ON m.id_estado = e.id_estado
        WHERE c.CP = ?";

$stmt = $conexion->prepare($sql);
$stmt->bind_param("s", $cp);
$stmt->execute();
$result = $stmt->get_result();

$colonias = [];
while ($row = $result->fetch_assoc()) {
    $colonias[] = [
        'id_colonia' => $row['id_colonia'],
        'nombre' => $row['nombre_colonia'],
        'estado' => $row['estado']
    ];
}

echo json_encode($colonias);
?>
