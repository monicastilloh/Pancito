<?php
include 'conexion.php';

header('Content-Type: application/json');

try {
    $sql = "SELECT id_tipo, nombre FROM ProductoTipo";
    $result = $conexion->query($sql);
    
    if (!$result) {
        throw new Exception("Error en la consulta: " . $conexion->error);
    }
    
    $tipos = [];
    while ($row = $result->fetch_assoc()) {
        $tipos[] = $row;
    }
    
    echo json_encode($tipos);

} catch (Exception $e) {
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
} finally {
    $conexion->close();
}
?>